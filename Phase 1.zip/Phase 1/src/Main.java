import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        MovieManager movieManager = new MovieManager();
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("1. Add Movie");
            System.out.println("2. View All Movies");
            System.out.println("3. Update Movie");
            System.out.println("4. Delete Movie");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            choice = Integer.parseInt(scanner.nextLine());

            switch (choice) {
                case 1:
                    movieManager.addMovie();
                    break;
                case 2:
                    movieManager.viewMovies();
                    break;
                case 3:
                    movieManager.updateMovie();
                    break;
                case 4:
                    movieManager.deleteMovie();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        } while (choice != 5);
    }
}