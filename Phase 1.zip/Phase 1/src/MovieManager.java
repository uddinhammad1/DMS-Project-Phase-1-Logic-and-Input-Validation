import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MovieManager {
    private List<Movie> movieList = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);

    // Add a new movie
    public void addMovie() {
        try {
            System.out.print("Enter movie title: ");
            String title = scanner.nextLine();

            System.out.print("Enter genre: ");
            String genre = scanner.nextLine();

            System.out.print("Enter release year: ");
            int releaseYear = Integer.parseInt(scanner.nextLine());  // Validate integer input

            System.out.print("Enter director name: ");
            String director = scanner.nextLine();

            System.out.print("Enter rating (out of 10): ");
            double rating = Double.parseDouble(scanner.nextLine());  // Validate double input

            System.out.print("Enter duration (minutes): ");
            int duration = Integer.parseInt(scanner.nextLine());  // Validate integer input

            Movie movie = new Movie(title, genre, releaseYear, director, rating, duration);
            movieList.add(movie);
            System.out.println("Movie added successfully!\n");
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter numbers for release year, rating, and duration.");
        }
    }

    // View all movies
    public void viewMovies() {
        if (movieList.isEmpty()) {
            System.out.println("No movies available.");
        } else {
            for (Movie movie : movieList) {
                System.out.println(movie);
            }
        }
    }

    // Update a movie's details
    public void updateMovie() {
        System.out.print("Enter movie title to update: ");
        String title = scanner.nextLine();
        Movie movieToUpdate = findMovieByTitle(title);

        if (movieToUpdate != null) {
            System.out.print("Enter new genre: ");
            String genre = scanner.nextLine();
            movieToUpdate.setGenre(genre);

            System.out.print("Enter new rating (out of 10): ");
            double rating = Double.parseDouble(scanner.nextLine());
            movieToUpdate.setRating(rating);

            System.out.println("Movie updated successfully!\n");
        } else {
            System.out.println("Movie not found.");
        }
    }

    // Delete a movie by title
    public void deleteMovie() {
        System.out.print("Enter movie title to delete: ");
        String title = scanner.nextLine();
        Movie movieToDelete = findMovieByTitle(title);

        if (movieToDelete != null) {
            movieList.remove(movieToDelete);
            System.out.println("Movie deleted successfully!");
        } else {
            System.out.println("Movie not found.");
        }
    }

    // Find a movie by title
    private Movie findMovieByTitle(String title) {
        for (Movie movie : movieList) {
            if (movie.getTitle().equalsIgnoreCase(title)) {
                return movie;
            }
        }
        return null;


    }

}
