public class Movie {


    private String title;
    private String genre;
    private int releaseYear;
    private String director;
    private double rating; // e.g., 7.5 out of 10
    private int duration;  // duration in minutes

    // Constructor
    public Movie(String title, String genre, int releaseYear, String director, double rating, int duration) {
        this.title = title;
        this.genre = genre;
        this.releaseYear = releaseYear;
        this.director = director;
        this.rating = rating;
        this.duration = duration;
    }

    // Getters and setters for each attribute
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    @Override
    public String toString() {
        return "Title: " + title + ", Genre: " + genre + ", Year: " + releaseYear +
                ", Director: " + director + ", Rating: " + rating + ", Duration: " + duration + " minutes";


    }
}